import React, { useEffect, useState } from "react";
import Accordion from "react-bootstrap/Accordion";
import { Container, Row, Col, Form, Button, Card } from "react-bootstrap";
import { colors } from "../../styles/colors";
import Grafico from "./Grafico";
import Tabla from "./Tabla";
import { ObtenerProductos } from "../../services/producto.service";

function MiComponente(){
  const [datos,setDatos]= useState([]);

  useEffect
}

function DentalPage() {
  return (
    <Container fluid style={{ marginTop:0}}>
      <Row>
        {/* Columna izquierda: acordeón */}
        <Col md={4} style={{ backgroundColor: "#f7f7f7ff", padding: "20px" ,margin:0}}>
          <Accordion defaultActiveKey={["0"]} alwaysOpen>
            <Accordion.Item eventKey="0">
              <Accordion.Header>INGRESOS</Accordion.Header>
              <Accordion.Body>Metálicos, Estéticos, Zafiro</Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="1">
              <Accordion.Header>AJUSTES</Accordion.Header>
              <Accordion.Body>Limpieza dental profesional</Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="2">
              <Accordion.Header>COMPARTE</Accordion.Header>
              <Accordion.Body>Implantes dentales con seguimiento profesional</Accordion.Body>
            </Accordion.Item>
          </Accordion>          
          <Grafico></Grafico>
        </Col>

{/* CARDSSS Columna derecha: contenido + form flotante */}
        <Col md={8} style={{ backgroundColor:colors.primary, position: "relative", padding: "20px" }}>
          
         <div className="cards" style={{
            display:'flex',
            flexWrap:'wrap',
            gap:10,
            width:'70%',
            
        }}>              
           <h2>Gastos Del Dia</h2>
          <p>
            “La gestión de gastos personales no se trata de gastar menos, sino de gastar con propósito.”
          </p>
          <Tabla></Tabla>               
        </div>
{/* Form flotante a la derecha */}
          <div className="forms">
          <Card
            style={{
              width: "250px",
              position: "absolute",
              top: "20px",
              right: "20px",
              padding: "10px",
              boxShadow: "0 0 10px rgba(0,0,0,0.1)",
              backgroundColor: colors.gray100
            }}
          >
            <Card.Body>
              <Card.Title>Agregar Gasto </Card.Title>
              <Form>
                <Form.Group className="mb-2">
                  <Form.Label>XXXX</Form.Label>
                  <Form.Control type="text" placeholder="Tu nombre" />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>XXX</Form.Label>
                  <Form.Control type="email" placeholder="Tu email" />
                </Form.Group>
                <Form.Group className="mb-2">
                  <Form.Label>Fecha</Form.Label>
                  <Form.Control type="date" />
                </Form.Group>
                <Button variant="success" type="submit" className="w-100">
                  Agregar
                </Button>
              </Form>
            </Card.Body>
          </Card>
          </div>
        </Col>
      </Row>
    </Container>
  );
}

export default DentalPage;


