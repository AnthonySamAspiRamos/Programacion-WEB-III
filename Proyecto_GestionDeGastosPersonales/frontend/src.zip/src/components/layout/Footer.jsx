import Nav from 'react-bootstrap/Nav';
import { colors } from '../../styles/colors';

function JustifiedExample() {
  return (
    <div className='footer' style={{
    position:'fixed',
    width:'100%',
    backgroundColor:colors.primaryDark,
    bottom: 0,
    zIndex: 999}}>
      
    <Nav justify variant="tabs" defaultActiveKey="/home" 
    style={{bottom: 0,
    marginLeft:'25%',       
    width: '50%',        
    zIndex: 999}}>
      <Nav.Item >
        <Nav.Link href="/home" style={{color:'black'}}>HOME</Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link eventKey="link-1" style={{color:'black'}}>VER OFERTAS</Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link eventKey="link-2" style={{color:'black'}}>AGENDAR CITA</Nav.Link>
      </Nav.Item>      
    </Nav>
    </div>
  );
}

export default JustifiedExample;