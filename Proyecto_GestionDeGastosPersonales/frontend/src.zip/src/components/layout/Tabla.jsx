import { useState } from 'react';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import DatosTabla from './DatosTabla.jsx';

function FillExample() {
  return (
    <Tabs
      defaultActiveKey="profile"
      id="fill-tab-example"
      className="mb-3"
      fill
      style={{
        width:'100%'        
      }}
    >
      <Tab eventKey="home" title="DIA" >
        <DatosTabla></DatosTabla>
      </Tab>
      <Tab eventKey="profile" title="SEMANA">
        <DatosTabla></DatosTabla>
      </Tab>
      <Tab eventKey="longer-tab" title="MES">
        <DatosTabla></DatosTabla>
      </Tab>      
    </Tabs>
  );
}

export default FillExample;

{/*
export default function Tabla() {
  // Datos de ejemplo
  const gastos = [
    { fecha: "2025-12-01", tipo: "Comida", monto: 50 },
    { fecha: "2025-12-02", tipo: "Transporte", monto: 20 },
    { fecha: "2025-12-03", tipo: "Entretenimiento", monto: 30 },
    { fecha: "2025-12-04", tipo: "Comida", monto: 40 },
    { fecha: "2025-12-05", tipo: "Transporte", monto: 15 },
    { fecha: "2025-12-06", tipo: "Comida", monto: 25 },
  ];

  // Función para agrupar gastos por día, semana o mes
  const agruparGastos = (periodo) => {
    const agrupados = {};

    gastos.forEach((gasto) => {
      let key;
      const fecha = new Date(gasto.fecha);

      if (periodo === "dia") {
        key = gasto.fecha;
      } else if (periodo === "semana") {
        // Semana del año
        const primerDia = new Date(fecha.getFullYear(), 0, 1);
        const diaSemana = Math.floor(((fecha - primerDia) / 86400000 + primerDia.getDay() + 1) / 7);
        key = `Semana ${diaSemana}`;
      } else if (periodo === "mes") {
        const mes = fecha.getMonth() + 1;
        key = `Mes ${mes}`;
      }

      if (!agrupados[key]) agrupados[key] = 0;
      agrupados[key] += gasto.monto;
    });

    return agrupados;
  };

  const dias = agruparGastos("dia");
  const semanas = agruparGastos("semana");
  const meses = agruparGastos("mes");

  // Función para renderizar tabla
  const renderTabla = (titulo, datos) => (
    <div style={{ marginBottom: "20px" }}>
      <h5>{titulo}</h5>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Periodo</th>
            <th>Total Gastos</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(datos).map(([key, monto]) => (
            <tr key={key}>
              <td>{key}</td>
              <td>${monto}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );

  return (
    <div>
      {renderTabla("Gastos por Día", dias)}
      {renderTabla("Gastos por Semana", semanas)}
      {renderTabla("Gastos por Mes", meses)}
    </div>
  );
}*/}
