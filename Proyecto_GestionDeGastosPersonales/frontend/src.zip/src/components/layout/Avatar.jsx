import { Nav, NavDropdown, Image } from "react-bootstrap";
import { colors } from "../../styles/colors";
function Avatar(){
<Nav className="ms-auto">
  <NavDropdown
    title={
      <Image
        src="/img/avatar.png"   // reemplaza con la ruta de tu imagen
        roundedCircle
        width={40}
        height={40}
        style={{
            backgroundColor:colors.dark,
          objectFit: "cover",
          cursor: "pointer",
          border: "2px solid #fff"
        }}
      />
    }
    id="nav-dropdown-profile"
    align="end"
  >
    <NavDropdown.Item href="#profile">Mi Perfil</NavDropdown.Item>
    <NavDropdown.Item href="#settings">Configuración</NavDropdown.Item>
    <NavDropdown.Divider />
    <NavDropdown.Item href="#logout">Cerrar Sesión</NavDropdown.Item>
  </NavDropdown>
</Nav>
}
export default Avatar;
