const Dashboard = () => {

  return (
    <div className="space-y-6">
      hola
    </div>
  );
};

export default Dashboard;
