import React, { useState } from 'react';
//import { BrowserRouter } from 'react-router-dom';
import Navdar from './components/layout/Navdar.jsx';
import Aside from './components/layout/Aside.jsx';
import Footer from './components/layout/Footer.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';
import AppRoutes from './routes/AppRoutes.jsx';

function Dent(){
    return(
        <div className='header' >
            <Navdar></Navdar>           
            <div className='aside'>
                <Aside></Aside>                
            </div>                      
            <Footer></Footer>
        </div>
    );
}
export default Dent;