import axios from 'axios'

export const ObtenerProductos =async()=>{
    const resultado = await axios.get('http://localhost:3001/productos')
    return resultado.data;
}